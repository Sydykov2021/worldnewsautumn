<table bgcolor="#FFFFFF" border="0" cellpadding="0" cellspacing="0" align="left" valign="top" width="245">
<tr>
	<td><img src="top.gif" width="245" height="48" alt=""></td>
</tr>
<tr>
	<td background="bg.gif" width="245"><? include("notes.php"); ?><br><br><p align="right"><font size="1"><a href="add.php">Post a Note</a></font>&nbsp;&nbsp;</p></td>
</tr>
<tr>
	<td background="bg.gif" width="245"><img src="bottom.gif" width="245" height="30" alt=""></td>
</tr>
</table>