Sticky Notes --- Copyright� Stephen Craton 2002
_______________________________________________

To install:

To install Sticky Notes, simply add the following code anywhere on your site where you want the panel to appear:

<?php
	include("*DIR*/stick.php");
?>

Replace *DIR* with the path of where you uplaoded the files. For example, if you uploaded your files into a folder called "notes" and your homepage is located in the root directory, you would put the following:

include("/notes/stick.php");

If you have any questions, problems, comments, or anything else, please email me at tenchi_no_chikara@msn.com or visit my website located at http://tlictlacs.gorzek.com. Thanks!