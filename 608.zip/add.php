<html>
<head>
  <title>Sticky Notes :: Add a Note</title>
</head>
<body bgcolor="#FFFFFF" link="#000084" vlink="#000000" text="#000000">
<?
if(!$submit)
{
?>
<form action="<? $PHP_SELF ?>">
<table bgcolor="#FFFFFF" border="0" width="75%" align="center">
<tr>
	<td width="25%">Post Icon:</td>
	<td width="75%"><input name="icon" type="radio" value="smile"><img src="smile1.gif"><input name="icon" type="radio" value="none">None</td>
</tr>
<tr>
	<td width="25%">Post Note:</td>
	<td width="75%"><textarea name="note" rows="5" cols="25"></textarea></td>
</tr>
<tr>
	<td width="100%" align="center" colspan="2"><input type="submit" name="submit" value="Post It!"></td>
</tr>
</table>
<?
}
else
{
	if($icon == "smile")
	{ $postit = "<img src='smile1.gif' align='left' width='16' height='12'>$note<hr width='25%' align='center'>"; }
	else
	{ $postit = "$note<hr width='25%' align='center'>"; }
$postit = stripslashes($postit);
$fp = fopen("notes.php", "w+");
fwrite($fp, $postit);
?>
<table align="center" width="75%" border="1" cellpadding="2" cellspacing="0" bordercolor="#000000">
<tr>
	<td>Post was successful! Your post said:</td>
</tr>
<tr>
	<td><? echo $postit ?></td>
</tr>
</table>
<?
}
?>
</body>
</html>

